/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,c;
    
    printf("enter 3 numbers:");
    scanf("%d%d%d",&a,&b,&c);
     if(a>b  && a>c){
         printf("a is largest number",);
         
     }
     else if(b>a && b>c){
         printf("b is largest number");
     }
else {
    printf ("c is largest number");
}
    return 0;
}