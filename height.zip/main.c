/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float a;
    printf("Enter your height:");
    scanf("%f",&a);
    if (a<150){
        printf("DWARF");
    }
    else if (a==150){
        printf("AVERAGE HEIGHT");
    }
    else if (a>150 && a<165){
        printf("middle");
    }
    else{
        printf("tall");
    }
    
    return 0;
    
}