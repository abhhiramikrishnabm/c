/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int number;
    
    printf("enter a number:");
    scanf("%d",&number);
    //(number>0)?(printf("number is positive")):(printf("number is negative"));
    (number<0)?(printf("number is negative")):(printf("number is positive"));

    return 0;
}